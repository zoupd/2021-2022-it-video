import FooterToolBar from './FooterToolBar'
import './index.less'

export default FooterToolBar
